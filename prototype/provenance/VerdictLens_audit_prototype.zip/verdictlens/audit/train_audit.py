"""Train challengers on original train; calibrate/tune on disjoint validation halves."""
import json
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.calibration import CalibratedClassifierCV, calibration_curve
from sklearn.frozen import FrozenEstimator
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (average_precision_score,roc_auc_score,brier_score_loss,
    log_loss,precision_recall_curve,confusion_matrix)
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer,StandardScaler
from audit_engine import ROOT, FEATURES, Auditor, save_json, sha256
from model_support import PrepareInputs, TARGET

OUT = Path(__file__).parent

def measures(y,p,t):
    tn,fp,fn,tp = confusion_matrix(y,p>=t,labels=[0,1]).ravel()
    frac,mean = calibration_curve(y,p,n_bins=10,strategy='quantile')
    return {'roc_auc':float(roc_auc_score(y,p)),'average_precision':float(average_precision_score(y,p)),
        'brier':float(brier_score_loss(y,p)),'log_loss':float(log_loss(y,p)),
        'precision':float(tp/max(tp+fp,1)), 'recall':float(tp/max(tp+fn,1)),
        'f1':float(2*tp/max(2*tp+fp+fn,1)), 'threshold':float(t),
        'confusion_matrix':[[int(tn),int(fp)],[int(fn),int(tp)]],
        'calibration_bins':{'mean_prediction':mean.tolist(),'observed_rate':frac.tolist()}}

def main():
    df = pd.read_csv(ROOT/'primary_model/cleaned_labeled_data.csv')
    manifest = pd.read_csv(ROOT/'primary_model/split_manifest.csv')
    assert df.source_row_id.is_unique
    pd.testing.assert_frame_equal(df[['source_row_id','split']],manifest)
    X,y = df[FEATURES],df[TARGET]
    groups = pd.util.hash_pandas_object(PrepareInputs().fit_transform(X),index=False).to_numpy()
    indices = {s:np.flatnonzero(df.split.eq(s)) for s in ['train','validation','test']}
    for a,b in [('train','validation'),('train','test'),('validation','test')]:
        assert not set(groups[indices[a]]) & set(groups[indices[b]])
    val = indices['validation']
    splitter = StratifiedGroupKFold(n_splits=2,shuffle=True,random_state=2026)
    cal,pol = next(splitter.split(X.iloc[val],y.iloc[val],groups[val]))
    cal,pol = val[cal],val[pol]
    assert not set(groups[cal]) & set(groups[pol])
    tr,te = indices['train'],indices['test']
    pd.DataFrame({'source_row_id':df.iloc[np.r_[cal,pol]].source_row_id,
        'audit_role':['calibration']*len(cal)+['policy']*len(pol)}).to_csv(OUT/'validation_roles.csv',index=False)
    primary = joblib.load(ROOT/'primary_model/primary_model.joblib')
    old = pd.read_csv(ROOT/'primary_model/holdout_predictions.csv').set_index('source_row_id')
    primary_test = primary['pipeline'].predict_proba(X.iloc[te])[:,1]
    expected = old.loc[df.iloc[te].source_row_id,'serious_delinquency_risk'].to_numpy()
    np.testing.assert_allclose(primary_test,expected,rtol=0,atol=1e-7)
    np.testing.assert_allclose(primary['pipeline'].named_steps['impute'].statistics_,X.iloc[tr].median(),rtol=0,atol=1e-12)
    models = {
        'logistic':Pipeline([('prepare',PrepareInputs()),('impute',SimpleImputer(strategy='median',add_indicator=True)),
            ('log',FunctionTransformer(np.log1p,feature_names_out='one-to-one')),('scale',StandardScaler()),
            ('model',LogisticRegression(C=1.0,max_iter=2000,random_state=2026))]),
        'random_forest':Pipeline([('prepare',PrepareInputs()),('impute',SimpleImputer(strategy='median',add_indicator=True)),
            ('model',RandomForestClassifier(n_estimators=180,max_depth=16,min_samples_leaf=25,
                max_features=0.8,n_jobs=1,random_state=2026))])}
    calibrated,thresholds,results = {},{},{}
    for name,model in models.items():
        print('Training',name,flush=True)
        model.fit(X.iloc[tr],y.iloc[tr])
        model = CalibratedClassifierCV(FrozenEstimator(model),method='sigmoid')
        model.fit(X.iloc[cal],y.iloc[cal])
        ppol = model.predict_proba(X.iloc[pol])[:,1]
        pr,rc,ts = precision_recall_curve(y.iloc[pol],ppol)
        f1 = 2*pr[:-1]*rc[:-1]/np.maximum(pr[:-1]+rc[:-1],1e-15)
        thresholds[name] = float(ts[np.argmax(f1)])
        calibrated[name] = model
        results[name] = {'policy':measures(y.iloc[pol],ppol,thresholds[name])}
    # Persist choices before evaluating original holdout labels.
    reference = {f:{'min':float(X.iloc[tr][f].min()),'max':float(X.iloc[tr][f].max()),
        **{k:float(X.iloc[tr][f].quantile(q)) for k,q in [('q01',.01),('q25',.25),('q75',.75),('q99',.99)]}} for f in FEATURES}
    config = {'audit_version':'1.0.0','primary_sha256':sha256(ROOT/'primary_model/primary_model.joblib'),
        'primary_threshold':primary['threshold'],'challenger_thresholds':thresholds,
        'threshold_offsets':[-.02,-.01,0,.01,.02], 'reference':reference,
        'policy':'Any input quality flag, challenger decision disagreement, threshold flip or input probe flip -> REVIEW; never override primary.',
        'policy_status':'Predeclared hackathon heuristics; not optimized for review capacity or business cost.',
        'training_rows':len(tr),'calibration_rows':len(cal),'policy_rows':len(pol),'test_rows':len(te)}
    save_json(OUT/'audit_config.json',config)
    joblib.dump(calibrated,OUT/'challengers.joblib',compress=3)
    preds = pd.DataFrame({'source_row_id':df.iloc[te].source_row_id.to_numpy(),'actual':y.iloc[te].to_numpy(),'primary':primary_test})
    for name,model in calibrated.items():
        p = model.predict_proba(X.iloc[te])[:,1]
        preds[name] = p
        results[name]['test'] = measures(y.iloc[te],p,thresholds[name])
        results[name]['test_common_threshold'] = measures(y.iloc[te],p,primary['threshold'])
        print(name,json.dumps(results[name]['test']),flush=True)
    results['primary'] = {'test':measures(y.iloc[te],primary_test,primary['threshold'])}
    pt = primary['threshold']
    preds['policy_disagreement'] = np.logical_or.reduce([(preds[n]>=thresholds[n]) != (preds.primary>=pt) for n in calibrated])
    preds['common_threshold_disagreement'] = np.logical_or.reduce([(preds[n]>=pt) != (preds.primary>=pt) for n in calibrated])
    preds['threshold_sensitive'] = ((preds.primary>=max(0,pt-.02)) != (preds.primary>=min(1,pt+.02)))
    results['holdout_signals'] = {c:{'count':int(preds[c].sum()),'rate':float(preds[c].mean())}
        for c in ['policy_disagreement','common_threshold_disagreement','threshold_sensitive']}
    results['verification'] = {'split_manifest_matches':True,'cross_partition_predictor_overlap':0,
        'primary_predictions_max_absolute_difference':float(np.max(np.abs(primary_test-expected))),
        'primary_train_only_medians_match':True,'calibration_policy_group_overlap':0}
    preds.to_csv(OUT/'holdout_comparison.csv',index=False)
    save_json(OUT/'evaluation.json',results)
    auditor = Auditor()
    # Examples are deliberately selected diagnostic demonstrations, not an evaluation sample.
    sample_indices = [int(te[np.argmin(primary_test)]),int(te[np.argmax(primary_test)]),
        int(te[np.argmin(np.abs(primary_test-pt))])]
    disagreement = np.flatnonzero(preds.policy_disagreement.to_numpy())
    if len(disagreement): sample_indices.append(int(te[disagreement[0]]))
    apps = json.loads(X.iloc[sample_indices].to_json(orient='records'))
    names = ['low_risk','high_risk','nearest_threshold','model_disagreement'][:len(apps)]
    missing = dict(apps[0]); missing['MonthlyIncome']=None; missing['NumberOfDependents']=None
    unusual = dict(apps[0]); unusual['NumberOfTimes90DaysLate']=98
    apps += [missing,unusual]; names += ['missing_inputs','ambiguous_late_count']
    save_json(OUT/'sample_applicants.json',apps)
    save_json(OUT/'sample_results.json',[{'sample':n,'source':'heldout selected example' if i<len(sample_indices) else 'synthetic modification',
        'source_row_id':int(df.iloc[sample_indices[i]].source_row_id) if i<len(sample_indices) else None,
        'applicant':a,'audit':auditor.audit(a)} for i,(n,a) in enumerate(zip(names,apps))])
    print('Saved models, evaluation and sample audits.',flush=True)

if __name__ == '__main__': main()
