"""VerdictLens deterministic audit. No network calls and no decision override."""
import argparse
import hashlib
import json
import math
import sys
from pathlib import Path
import joblib
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'primary_model'))
from model_support import FEATURES

COUNT_FIELDS = [f for f in FEATURES if f.startswith('Number')] + ['age']
LATE_FIELDS = [f for f in FEATURES if 'PastDue' in f or f == 'NumberOfTimes90DaysLate']

def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save_json(path, obj):
    Path(path).write_text(json.dumps(obj, indent=2, allow_nan=False), encoding='utf-8')

def decision(p, threshold):
    return 'REJECT' if p >= threshold else 'APPROVE'

def validate(applicant):
    if not isinstance(applicant, dict):
        raise ValueError('Each applicant must be a JSON object.')
    missing, extra = set(FEATURES)-set(applicant), set(applicant)-set(FEATURES)
    if missing or extra:
        raise ValueError(f'Feature mismatch: missing={sorted(missing)}, extra={sorted(extra)}')
    result = {}
    for name in FEATURES:
        value = applicant[name]
        if value is None:
            result[name] = None
            continue
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
            raise ValueError(f'{name} must be a finite nonnegative number or null.')
        if name in COUNT_FIELDS and value != int(value):
            raise ValueError(f'{name} must be an integer or null.')
        result[name] = float(value)
    return result

class Auditor:
    def __init__(self, directory=None):
        directory = Path(directory or Path(__file__).parent)
        self.config = json.loads((directory / 'audit_config.json').read_text())
        primary = ROOT / 'primary_model' / 'primary_model.joblib'
        if sha256(primary) != self.config['primary_sha256']:
            raise ValueError('Primary model differs from the audited version.')
        self.primary = joblib.load(primary)
        self.challengers = joblib.load(directory / 'challengers.joblib')
        self.threshold = float(self.primary['threshold'])

    def scenarios(self, a):
        """Local diagnostic probes, not causal recourse or global robustness proof."""
        cases = []
        def add(name, changes, kind):
            b = dict(a)
            b.update(changes)
            cases.append((name, changes, kind, b))
        for f in ['RevolvingUtilizationOfUnsecuredLines', 'DebtRatio']:
            if a[f] is not None and a[f] > 0:
                for factor in [0.95, 1.05]:
                    add(f'{f}_x{factor}', {f:a[f]*factor}, 'measurement_sensitivity')
        income, ratio = a['MonthlyIncome'], a['DebtRatio']
        if income is not None and income > 0 and ratio is not None:
            for factor in [0.95, 1.05]:
                add(f'income_x{factor}_fixed_debt_payments',
                    {'MonthlyIncome':income*factor,'DebtRatio':ratio/factor}, 'conditional_scenario')
        for f in FEATURES:
            if a[f] is None or (f == 'age' and a[f] == 0):
                for q in ['q25','q75']:
                    add(f'{f}_missing_to_{q}', {f:self.config['reference'][f][q]}, 'missing_value_sensitivity')
        if a['age'] is not None and a['age'] > 1:
            for delta in [-1,1]:
                add(f'age_record_delta_{delta}', {'age':a['age']+delta}, 'record_sensitivity_not_actionable')
        return cases

    def audit(self, applicant):
        a = validate(applicant)
        frame = pd.DataFrame([a], columns=FEATURES)
        p = float(self.primary['pipeline'].predict_proba(frame)[0,1])
        d = decision(p,self.threshold)
        flags, quality = [], []
        for f,v in a.items():
            r = self.config['reference'][f]
            if v is None or (f == 'age' and v == 0):
                quality.append({'code':'IMPUTED_INPUT','feature':f})
            elif v < r['min'] or v > r['max']:
                quality.append({'code':'OUTSIDE_TRAINING_RANGE','feature':f})
            elif v < r['q01'] or v > r['q99']:
                quality.append({'code':'TRAINING_TAIL','feature':f})
            if f in LATE_FIELDS and v in [96,98]:
                quality.append({'code':'AMBIGUOUS_LATE_COUNT','feature':f})
        if quality:
            flags.append('INPUT_QUALITY_REVIEW')
        models = []
        for name, model in self.challengers.items():
            cp = float(model.predict_proba(frame)[0,1])
            ct = self.config['challenger_thresholds'][name]
            models.append({'model':name,'risk_estimate':cp,'own_policy_threshold':ct,
                'own_policy_decision':decision(cp,ct),
                'at_primary_threshold_decision':decision(cp,self.threshold),
                'signed_difference_from_primary':cp-p})
        if any(m['own_policy_decision'] != d for m in models):
            flags.append('MODEL_POLICY_DISAGREEMENT')
        if any(m['at_primary_threshold_decision'] != d for m in models):
            flags.append('COMMON_THRESHOLD_DISAGREEMENT')
        threshold_tests = [{'threshold':float(np.clip(self.threshold+offset,0,1)),
            'decision':decision(p,float(np.clip(self.threshold+offset,0,1)))}
            for offset in self.config['threshold_offsets']]
        if any(t['decision'] != d for t in threshold_tests):
            flags.append('THRESHOLD_SENSITIVE')
        cases = self.scenarios(a)
        probes = []
        if cases:
            pp = self.primary['pipeline'].predict_proba(pd.DataFrame([s[3] for s in cases],columns=FEATURES))[:,1]
            for (name,changes,kind,_),prob in zip(cases,pp):
                probes.append({'scenario':name,'kind':kind,'changes':changes,'risk_estimate':float(prob),
                    'risk_delta':float(prob)-p,'decision':decision(float(prob),self.threshold),
                    'decision_flipped':decision(float(prob),self.threshold)!=d})
        if any(s['decision_flipped'] for s in probes):
            flags.append('INPUT_SENSITIVE')
        result = {'schema_version':'1.0','audit_version':self.config['audit_version'],
            'primary':{'risk_estimate':p,'threshold':self.threshold,'decision':d,
                'signed_margin':p-self.threshold},
            'status':'REVIEW' if flags else 'NO_FLAGS_IN_CHECKS', 'flags':flags,
            'input_quality':quality,'challengers':models,'threshold_sensitivity':threshold_tests,
            'input_sensitivity':probes,
            'limitations':['Review flags do not prove a wrong or unfair decision.',
                'Sensitivity probes are local diagnostics, not causal advice or a fairness certification.',
                'All models share historical data and may share errors; no automated decision override.']}
        result['explanation'] = self.explain(result)
        return result

    @staticmethod
    def explain(result):
        p = result['primary']
        text = f"The demo primary model returns {p['decision']} with estimated risk {p['risk_estimate']:.1%}, using a {p['threshold']:.1%} threshold. "
        if result['flags']:
            text += 'Review signals: ' + ', '.join(result['flags']) + '. These signals do not establish that the decision is incorrect.'
        else:
            text += 'No flags were found in the configured checks; this is not a guarantee of correctness.'
        return text

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input',required=True,type=Path)
    parser.add_argument('--output',type=Path)
    args = parser.parse_args()
    data = json.loads(args.input.read_text(encoding='utf-8-sig'))
    auditor = Auditor()
    result = [auditor.audit(a) for a in data] if isinstance(data,list) else auditor.audit(data)
    if args.output:
        save_json(args.output,result)
    else:
        print(json.dumps(result,indent=2,allow_nan=False))

if __name__ == '__main__':
    main()
