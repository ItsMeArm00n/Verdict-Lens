# Minimal later prototype integration

## Flow

Applicant form → Python backend input validation → frozen primary model + VerdictLens auditor → structured audit response → optional Gemini explanation → results view.

The primary model and auditor run in the same Python service for the hackathon. Load an `Auditor` once per worker at startup. Keep artifacts on the server and pin their versions. The browser receives results, never model files or API credentials. UI/UX implementation is deliberately deferred.

## Endpoint contract

`POST /api/audit` accepts an `applicant` object containing exactly the ten named features listed in the package inventory. Accept numeric values or explicit JSON null; count fields and age must be whole numbers. Ratios are fractions (0.30 means 30%); income uses the dataset's units. No target label, identity, or outcome is an input. Map validation errors to HTTP 422. Generate a request ID server-side.

```python
from audit.audit_engine import Auditor

auditor = Auditor()

def audit_request(payload):
    return auditor.audit(payload['applicant'])
```

The result includes:

| Field | Meaning |
|---|---|
| `schema_version`, `audit_version` | Response and artifact version |
| `primary` | Original risk estimate, threshold, decision and signed margin |
| `status`, `flags` | Review result with explicit reason codes |
| `challengers` | Risk estimates and decisions under own and common thresholds |
| `input_quality` | Imputation, range, tail and ambiguous-value findings |
| `threshold_sensitivity` | Policy thresholds and corresponding decisions |
| `input_sensitivity` | Exact changed fields, scores, deltas and decision flips |
| `explanation` | Deterministic readable fallback |
| `limitations` | Meaning and boundaries of the checks |

Initial results view needs only the primary decision, review status, reason list, challenger comparison and expandable sensitivity evidence. Present high-risk classification as a demo policy result rather than a factual prediction that a person will default.

## Gemini boundary

Add optional `POST /api/explain` later, or invoke explanation generation after `/api/audit`. Configure the Gemini key through a server-side environment variable. No Gemini SDK, credential, or network request is needed for this working audit package.

Send only the structured audit facts required for explanation; omit raw applicant records, identifying data and historical datasets. Restrict output to a short summary and evidence references. Treat Gemini text as commentary and never allow it to modify scores, thresholds, flags, status or decisions. Display numeric evidence directly from the audit JSON, not from generated prose. On a timeout, API error or unsupported claim, return the existing template explanation.

Suggested instruction:

> Explain only the supplied VerdictLens audit JSON in plain language. Separate the primary prediction from review signals. Do not infer a person's character, actual future outcome, discrimination, or legal compliance. Do not recommend changing age or invent causal advice. Do not reverse a decision or add numbers. Each explanation must reference an existing evidence field. If evidence is insufficient, state that limitation.

Keep generated prose visibly separate from computed results. A language model may still make mistakes; schema checks alone do not establish factual correctness. For a robust demo, use templates for facts and Gemini only for optional paraphrasing, with fallback whenever evidence references fail validation.

## Operational minimum

Validate content type and request size, keep API keys server-side, set a short explanation timeout, and avoid logging full applicant financial records. Persist request ID, artifact hashes and result flags if audit traceability is needed. A future model revision requires challenger evaluation and a new config bound to its hash; the current auditor rejects a mismatching primary artifact.

## What remains before real lending use

The target is serious delinquency, not decision correctness. Dataset coverage, drift, economic costs, review capacity, subgroup error rates, calibration and lawful data use would require separate assessment. This package demonstrates model-dependence and local sensitivity; it does not establish that flagged applicants were wrongly rejected or that unflagged applicants were fairly treated.
