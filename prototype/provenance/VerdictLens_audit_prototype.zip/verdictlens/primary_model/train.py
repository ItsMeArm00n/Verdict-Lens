"""Reproduce the primary model, fixed grouped holdout, and evaluation artifacts."""
import argparse
import hashlib
import json
import platform
from pathlib import Path

import joblib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import sklearn
import xgboost
from sklearn.calibration import calibration_curve
from sklearn.impute import SimpleImputer
from sklearn.metrics import (accuracy_score, average_precision_score, brier_score_loss,
    confusion_matrix, f1_score, log_loss, precision_recall_curve, precision_score,
    recall_score, roc_auc_score, roc_curve)
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.pipeline import Pipeline
from xgboost import XGBClassifier
from model_support import FEATURES, TARGET, PrepareInputs, predict_applications

SEED = 42

def save_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False), encoding='utf-8')

def measures(y, p, threshold):
    predicted = (p >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, predicted, labels=[0, 1]).ravel()
    return dict(roc_auc=float(roc_auc_score(y,p)), average_precision=float(average_precision_score(y,p)),
        log_loss=float(log_loss(y,p)), brier_score=float(brier_score_loss(y,p)),
        accuracy=float(accuracy_score(y,predicted)), precision=float(precision_score(y,predicted,zero_division=0)),
        recall=float(recall_score(y,predicted,zero_division=0)), f1=float(f1_score(y,predicted,zero_division=0)),
        rejection_rate=float(predicted.mean()), threshold=float(threshold),
        true_negatives=int(tn), false_positives=int(fp), false_negatives=int(fn), true_positives=int(tp))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data-dir', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, default=Path(__file__).parent)
    args = parser.parse_args()
    out = args.output_dir
    out.mkdir(parents=True, exist_ok=True)
    source = args.data_dir / 'cs-training.csv'
    raw = pd.read_csv(source)
    assert set(raw[TARGET].unique()) == {0, 1}
    assert raw['Unnamed: 0'].is_unique
    raw_counts = {str(k): int(v) for k,v in raw[TARGET].value_counts().items()}
    missing = {k: int(v) for k,v in raw[FEATURES].isna().sum().items()}
    duplicates = raw.duplicated(subset=[TARGET] + FEATURES)
    df = raw.loc[~duplicates].copy().reset_index(drop=True)
    X, y = df[FEATURES], df[TARGET].astype(int)
    clean = PrepareInputs().fit_transform(X)
    # Group on predictors alone, including profiles with contradictory labels.
    groups = pd.util.hash_pandas_object(clean, index=False).to_numpy()
    outer = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=SEED)
    development, test = next(outer.split(X,y,groups))
    inner = StratifiedGroupKFold(n_splits=4, shuffle=True, random_state=SEED+1)
    train_rel, val_rel = next(inner.split(X.iloc[development],y.iloc[development],groups[development]))
    train, val = development[train_rel], development[val_rel]
    for a,b in [(train,val),(train,test),(val,test)]:
        assert not set(groups[a]) & set(groups[b]), 'Predictor overlap across partitions'
    splits = {'train':train, 'validation':val, 'test':test}
    split_summary = {name:dict(rows=len(idx), positives=int(y.iloc[idx].sum()),
        positive_rate=float(y.iloc[idx].mean())) for name,idx in splits.items()}
    print('SPLITS', json.dumps(split_summary), flush=True)
    manifest = pd.DataFrame({'source_row_id':df['Unnamed: 0'], 'split':''})
    for name,idx in splits.items(): manifest.loc[idx,'split'] = name
    manifest.to_csv(out/'split_manifest.csv', index=False)
    pd.DataFrame({'source_row_id':raw.loc[duplicates,'Unnamed: 0'],
        'reason':'exact duplicate of earlier labeled profile'}).to_csv(out/'excluded_rows.csv',index=False)
    cleaned_output = clean.copy()
    cleaned_output.insert(0,'source_row_id',df['Unnamed: 0'])
    cleaned_output[TARGET] = y
    cleaned_output['split'] = manifest['split']
    cleaned_output.to_csv(out/'cleaned_labeled_data.csv',index=False)
    configurations = [dict(max_depth=3,min_child_weight=10), dict(max_depth=4,min_child_weight=10),
        dict(max_depth=5,min_child_weight=20)]
    candidates = []
    fitted = []
    for config in configurations:
        pipeline = Pipeline([('prepare',PrepareInputs()),
            ('impute',SimpleImputer(strategy='median',add_indicator=True)),
            ('model',XGBClassifier(n_estimators=400,learning_rate=0.04,subsample=0.85,
                colsample_bytree=0.9,reg_lambda=5,objective='binary:logistic',
                eval_metric='logloss',tree_method='hist',n_jobs=4,random_state=SEED,**config))])
        pipeline.fit(X.iloc[train],y.iloc[train])
        p = pipeline.predict_proba(X.iloc[val])[:,1]
        row = dict(config=config, validation_average_precision=float(average_precision_score(y.iloc[val],p)),
            validation_roc_auc=float(roc_auc_score(y.iloc[val],p)),validation_log_loss=float(log_loss(y.iloc[val],p)))
        candidates.append(row)
        fitted.append(pipeline)
        print('CANDIDATE', json.dumps(row),flush=True)
    selected = max(range(len(candidates)), key=lambda i:(candidates[i]['validation_average_precision'],-candidates[i]['validation_log_loss']))
    pipeline = fitted[selected]
    pval = pipeline.predict_proba(X.iloc[val])[:,1]
    precision, recall, thresholds = precision_recall_curve(y.iloc[val],pval)
    f1 = 2*precision[:-1]*recall[:-1]/np.maximum(precision[:-1]+recall[:-1],1e-15)
    threshold = float(thresholds[int(np.argmax(f1))])
    # Configuration and policy are now frozen. Test labels only enter evaluation.
    ptest = pipeline.predict_proba(X.iloc[test])[:,1]
    test_metrics = measures(y.iloc[test],ptest,threshold)
    test_default = measures(y.iloc[test],ptest,0.5)
    validation_metrics = measures(y.iloc[val],pval,threshold)
    base = np.full(len(test),float(y.iloc[train].mean()))
    baseline = measures(y.iloc[test],base,0.5)
    medians = pipeline.named_steps['impute'].statistics_
    np.testing.assert_allclose(medians, clean.iloc[train].median().to_numpy())
    versions = dict(python=platform.python_version(),pandas=pd.__version__,numpy=np.__version__,
        scikit_learn=sklearn.__version__,xgboost=xgboost.__version__,joblib=joblib.__version__,matplotlib=matplotlib.__version__)
    metadata = dict(target=TARGET,target_definition='Serious delinquency within two years; not an observed approval/rejection decision',
        seed=SEED, features=FEATURES, data_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        data_source=str(source), raw_rows=len(raw), raw_class_counts=raw_counts,
        exact_duplicates_removed=int(duplicates.sum()), retained_rows=len(df),missing_before_cleaning=missing,
        age_zero_to_missing=int(raw['age'].eq(0).sum()),
        unusual_late_counts_retained={c:int(raw[c].isin([96,98]).sum()) for c in FEATURES if 'PastDue' in c or c=='NumberOfTimes90DaysLate'},
        cleaning='Drop row identifier from predictors; remove exact labeled duplicates; age 0 -> missing; retain finite nonnegative extremes including counts 96/98; group identical cleaned predictor profiles across splits.',
        split_summary=split_summary,split_method='StratifiedGroupKFold: outer 5 folds (first=test), inner 4 folds (first=validation), remaining=train',
        imbalance_strategy='Preserve natural prevalence; no oversampling or class weights; select by validation average precision and choose threshold on validation F1.',
        candidates=candidates,selected_candidate=selected,threshold=threshold,
        threshold_selection='Maximum positive-class F1 on validation only; first threshold on tie; illustrative hackathon policy, no business cost assumptions.',
        decision_rule='REJECT if estimated serious-delinquency risk >= threshold, else APPROVE',
        train_only_imputation_medians=dict(zip(FEATURES,medians.tolist())),
        validation=validation_metrics,test=test_metrics,test_at_0_5=test_default,constant_baseline=baseline,
        versions=versions,refit_on_validation_or_test=False)
    save_json(out/'metrics.json',metadata)
    bundle = dict(pipeline=pipeline,threshold=threshold,features=FEATURES,target=TARGET,metadata=metadata)
    joblib.dump(bundle,out/'primary_model.joblib',compress=3)
    pipeline.named_steps['model'].save_model(out/'xgboost_model.json')
    reloaded = joblib.load(out/'primary_model.joblib')
    np.testing.assert_array_equal(ptest,reloaded['pipeline'].predict_proba(X.iloc[test])[:,1])
    decisions = predict_applications(reloaded,X.iloc[test])
    assert np.array_equal(decisions.decision.eq('REJECT'),ptest>=threshold)
    # Ensure named-column ordering is handled and genuinely missing fields fail clearly.
    np.testing.assert_array_equal(ptest[:20],reloaded['pipeline'].predict_proba(X.iloc[test[:20]][FEATURES[::-1]])[:,1])
    try: predict_applications(reloaded,X.iloc[test[:1]].drop(columns=['age']))
    except ValueError: pass
    else: raise AssertionError('Missing column accepted')
    test_output = decisions.copy()
    test_output.insert(0,'source_row_id',df.iloc[test]['Unnamed: 0'].to_numpy())
    test_output.insert(1,'actual_serious_delinquency',y.iloc[test].to_numpy())
    test_output.to_csv(out/'holdout_predictions.csv',index=False)
    # Input example taken from training only. Missing values serialize as JSON null.
    example = json.loads(X.iloc[train[:1]].to_json(orient='records'))[0]
    save_json(out/'example_application.json',example)
    (out/'requirements.txt').write_text('\n'.join(f'{k.replace("_","-")}=={v}' for k,v in versions.items() if k!='python')+'\n',encoding='utf-8')
    # Scientific evaluation figure, not a VerdictLens audit.
    fig,axes = plt.subplots(2,2,figsize=(11,8),layout='constrained')
    fpr,tpr,_=roc_curve(y.iloc[test],ptest)
    axes[0,0].plot(fpr,tpr,label=f'XGBoost AUC {test_metrics["roc_auc"]:.3f}')
    axes[0,0].plot([0,1],[0,1],'--',color='gray')
    axes[0,0].set(xlabel='False positive rate',ylabel='True positive rate',title='Held-out ROC curve')
    axes[0,0].legend()
    pr,rc,_=precision_recall_curve(y.iloc[test],ptest)
    axes[0,1].plot(rc,pr,label=f'Average precision {test_metrics["average_precision"]:.3f}')
    axes[0,1].axhline(y.iloc[test].mean(),ls='--',color='gray',label='Prevalence baseline')
    axes[0,1].set(xlabel='Recall',ylabel='Precision',title='Held-out precision and recall')
    axes[0,1].legend()
    frac,mean=calibration_curve(y.iloc[test],ptest,n_bins=10,strategy='quantile')
    axes[1,0].plot(mean,frac,'o-')
    axes[1,0].plot([0,1],[0,1],'--',color='gray')
    axes[1,0].set(xlabel='Mean predicted risk',ylabel='Observed delinquency rate',title='Calibration (10 equal-count bins)')
    cm=confusion_matrix(y.iloc[test],ptest>=threshold)
    axes[1,1].imshow(cm,cmap='Blues')
    for (i,j),v in np.ndenumerate(cm): axes[1,1].text(j,i,f'{v:,}',ha='center',va='center',color='white' if v>cm.max()/2 else 'black',fontsize=15)
    axes[1,1].set(xticks=[0,1],yticks=[0,1],xticklabels=['Approve','Reject'],yticklabels=['No delinquency','Delinquency'],xlabel='Demo decision',ylabel='Observed outcome',title=f'Confusion matrix (threshold {threshold:.3f})')
    fig.suptitle('VerdictLens primary model | independent test evaluation',fontsize=16)
    fig.savefig(out/'evaluation.png',dpi=160)
    plt.close(fig)
    save_json(out/'verification.json',dict(group_overlap=0,train_only_medians_verified=True,
        saved_model_prediction_roundtrip=True,column_reordering_verified=True,missing_column_rejected=True,
        decision_threshold_verified=True))
    print('FINAL',json.dumps(test_metrics),flush=True)

if __name__=='__main__': main()
