"""Run: python predict.py --input applications.json [--model primary_model.joblib]."""
import argparse
import json
from pathlib import Path
import joblib
from model_support import predict_applications

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', required=True, type=Path)
    parser.add_argument('--model', type=Path, default=Path(__file__).with_name('primary_model.joblib'))
    args = parser.parse_args()
    bundle = joblib.load(args.model)
    result = predict_applications(bundle, json.loads(args.input.read_text(encoding='utf-8')))
    print(result.to_json(orient='records', indent=2))
