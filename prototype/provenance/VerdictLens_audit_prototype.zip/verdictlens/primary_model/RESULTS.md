# VerdictLens primary loan-risk model

The primary XGBoost model is trained, evaluated, and saved. No VerdictLens alternative models or auditing checks have been built.

## What it predicts

The model estimates the probability of serious delinquency within two years. The supplied dictionary defines serious delinquency as 90 days past due or worse. This is not an observed loan-approval label. The demo maps estimated risk to APPROVE or REJECT using a documented policy threshold.

## Data preparation

- Source: `cs-training.csv` in the supplied GiveMeSomeCredit folder; SHA-256: `1bd46da486a5708c58c7b01a034fae2a13b327f6f7b62ea7ba4fe3b5824b24ac`.
- Original records: 150,000; no serious delinquency: 139,974; serious delinquency: 10,026 (6.684%).
- Removed 609 exact duplicates after excluding the row ID; retained 149,391 records. IDs remain available for traceability but never enter the model.
- Missing income: 29,731 (19.82%); missing dependents: 3,924 (2.62%) in the original data.
- Replaced 1 zero age with missing. No other outlier clipping or speculative sentinel replacement. Values 96/98 in late-payment counts and extreme ratios remain as supplied because their encoding is undocumented. This is a known data-quality limitation.
- Median imputation and missingness indicators are fitted on training records only and stored in the pipeline. The cleaned CSV intentionally leaves missing values blank; imputation happens within the model.

## Split and leakage protection

Approximately 60% training / 20% validation / 20% final test. Group-aware stratification keeps identical cleaned predictor profiles together, even when their labels differ. The random seed is 42 (43 for the inner split).

| Partition | Records | Delinquency cases | Delinquency rate |
|---|---:|---:|---:|
| Train | 89,634 | 6,005 | 6.70% |
| Validation | 29,878 | 2,002 | 6.70% |
| Test | 29,879 | 2,002 | 6.70% |

Validation selects among three XGBoost configurations by average precision, with log loss as a tie-breaker. It also selects the policy threshold. Test records are excluded from imputation fitting, model fitting, configuration selection, and threshold selection. The saved model is the exact evaluated model, without a later refit. Split IDs and removed duplicate IDs are included for reproducibility.

The competition `cs-test.csv` has 101,503 rows and no outcome labels. It was not used for training, model selection, or evaluation.

## Primary model and policy

Selected configuration: `{'max_depth': 3, 'min_child_weight': 10}`. XGBoost uses 400 trees, learning rate 0.04, row sampling 0.85, column sampling 0.9, and L2 regularization 5. Natural class prevalence is preserved, with no synthetic examples or class reweighting. Imbalance is addressed through stratification, average-precision selection, and validation-based thresholding.

**Demo rule: REJECT when estimated risk is at least 0.178670 (17.87%); otherwise APPROVE.** Use the stored full-precision threshold in code.

The threshold maximizes validation positive-class F1. This balances precision and recall for a hackathon demonstration; it is not a lending policy derived from business costs. Risk is an estimated probability, not confidence that a rejection is correct. Probabilities have not been separately recalibrated; the figure reports observed calibration.

## Independent test results

The baseline predicts the training-set delinquency rate for everyone and approves everyone at threshold 0.5.

| Metric | XGBoost at demo threshold | Constant baseline |
|---|---:|---:|
| ROC-AUC | 0.8696 | 0.5000 |
| Average precision (PR summary) | 0.4152 | 0.0670 |
| Brier score (lower is better) | 0.0483 | 0.0625 |
| Log loss (lower is better) | 0.1752 | 0.2458 |
| Accuracy | 0.9133 | 0.9330 |
| High-risk precision | 0.3952 | 0.0000 |
| High-risk recall | 0.5549 | 0.0000 |
| High-risk F1 | 0.4617 | 0.0000 |

At the selected threshold:

- Correctly flags 1,111 of 2,002 actual delinquency cases: recall 55.49%.
- Of 2,811 demo rejections, 1,111 actually experienced delinquency: precision 39.52%.
- Incorrectly rejects 1,700 non-delinquent records and misses 891 delinquency cases.
- Correctly approves 26,177 non-delinquent records. Overall rejection rate: 9.41%.

| Actual outcome | Demo approve | Demo reject |
|---|---:|---:|
| No serious delinquency | 26,177 | 1,700 |
| Serious delinquency | 891 | 1,111 |

For reference, the same model at a fixed 0.50 threshold has precision 62.01%, recall 19.08%, and F1 0.2918. This comparison did not alter the selected threshold.

![Evaluation curves](evaluation.png)

## Saved package and usage

- `primary_model.joblib`: complete bundle with preprocessing, fitted XGBoost model, threshold, feature list, and metadata.
- `model_support.py`: required beside the bundle for its custom input preparation and `predict_applications` helper.
- `predict.py` and `example_application.json`: a working inference example.
- `train.py`, `requirements.txt`, `metrics.json`, `split_manifest.csv`, `excluded_rows.csv`, `cleaned_labeled_data.csv`, and `holdout_predictions.csv`: reproduction and evaluation records.
- `xgboost_model.json`: portable raw booster only. It does **not** include preprocessing or the policy; use the full bundle for inference.

Tested with Python 3.11.0. From this folder:

```powershell
python -m pip install -r requirements.txt
python predict.py --input example_application.json
python train.py --data-dir "C:\Users\armaa\Desktop\GiveMeSomeCredit"
```

Applications must supply all ten dataset feature names, using null for missing values. The helper reorders columns and ignores identifiers and other extra fields. Ratios use the original CSV scale (for example 0.5 rather than 50 for 50%); income must match the training data's monthly units. The source does not state currency, so do not assume AED. Loan amount, employment duration, and credit score are not features in this dataset.

Only load model bundles from trusted sources. Keep `model_support.py` importable when loading this bundle from another application.

## Verification and limits

Verified: zero identical-profile overlap across splits, imputation medians equal training-only medians, saved/reloaded probabilities identical, named-column reordering safe, missing required columns rejected, and decision labels match the stored threshold.

This is an offline hackathon prototype. The historical dataset and random holdout do not establish performance on current applicants or another country, future periods, or a different application population. No fairness, subgroup, regulatory, or VerdictLens contestability evaluation has been performed. The remaining false positives and missed cases are visible above.
