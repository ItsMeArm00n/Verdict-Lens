# VerdictLens audit prototype

VerdictLens audits the existing loan-risk model using two alternative models and reproducible diagnostic rules. It returns a review status alongside the original decision. The audit does not replace the primary model or automatically reverse its decision.

## Architecture decision

Use **trained challengers plus a deterministic audit layer**. Logistic regression provides a simple, additive view (after log transforms); random forest provides a different nonlinear model family from the primary boosted trees. Both learn actual delinquency labels. Their disagreement is evidence of model dependence, not proof that either model is correct.

An LLM has no grounded numerical basis for validating this classifier. A separately trained "decision correctness" classifier would require reliable audit labels and a separate evaluation design; the dataset only labels subsequent serious delinquency, not whether a loan decision was appropriate. We therefore do not invent audit labels, an "unfairness score," or a confidence percentage from vote counts.

The deterministic rules are inspectable and produce the same result for the same artifacts and applicant. Gemini is optional language generation after the audit has finished. A working template explanation is included, so the prototype works without an API key.

## Package layout

- `primary_model/`: all 16 files from the supplied ZIP, preserved.
- `audit/package_inventory.json`: every original filename, byte size, SHA-256, pipeline details, exact threshold, parameters and metadata.
- `audit/challengers.joblib`: fitted and sigmoid-calibrated logistic regression and random forest pipelines.
- `audit/audit_config.json`: frozen thresholds, review rules, training reference ranges and primary-model hash.
- `audit/validation_roles.csv`: calibration versus policy-selection assignments within the original validation partition.
- `audit/audit_engine.py`: callable auditor and JSON command-line entry point.
- `audit/train_audit.py`: reproducible challenger training and holdout evaluation.
- `audit/evaluation.json`, `audit/holdout_comparison.csv`: full original-test-set model comparisons.
- `audit/sample_applicants.json`, `audit/sample_results.json`: demonstration inputs and computed audit evidence.
- `audit/test_audit.py`, `audit/test_results.txt`: behavioral checks and captured test results.
- `AUDIT_REPORT.md`: inspection findings, measured results, sample outcomes and limitations.
- `INTEGRATION.md`: minimal later website/backend contract and explanation boundary.

## Run

Use Python 3.11 and the pinned versions in `requirements.txt`. From this directory:

```sh
python -m pip install -r requirements.txt
python audit/audit_engine.py --input audit/sample_applicants.json --output results.json
python -m unittest discover -s audit -p test_audit.py -v
```

To retrain the challengers using the bundled data and saved split assignments:

```sh
python audit/train_audit.py
```

All paths used by the auditor are relative to its own location. Keep `primary_model` and `audit` together. Model files use Python serialization and should only be loaded from a trusted build. The native XGBoost JSON is only the booster; it cannot replace the full preprocessing pipeline by itself.

## Audit interpretation

The primary threshold remains exactly **0.178669735789299**, with rejection at equality. Challengers have separate thresholds selected by validation F1; the report also compares all models using the primary threshold so score differences can be distinguished from threshold-policy differences. Scores are not averaged into a new lending decision.

The rules flag an applicant if any of these hold:

1. Challenger decisions differ from the primary decision, under their own policies or the common threshold.
2. Moving the primary threshold by ±1 or ±2 percentage points changes the decision.
3. A configured local input probe changes the primary decision.
4. Inputs need imputation, fall outside training ranges or the central 98% marginal range, or contain ambiguous late-payment counts 96/98.

Probe ranges are predeclared demo heuristics, not measured error bounds. Input probes include ±5% utilization, ±5% debt ratio, and ±5% income with debt ratio adjusted inversely under an explicit fixed-debt-payment assumption. Missing values are probed at training quartiles. Age ±1 is a record-sensitivity diagnostic, never an action recommendation. Historical late counts are flagged where ambiguous rather than rewritten.

`NO_FLAGS_IN_CHECKS` means only that these particular checks found no flags. `REVIEW` identifies evidence for a human to inspect. Neither is a fairness certification, a validated loan decision, or a probability of model error.

## Evaluation boundaries

The original model is frozen. Challengers fit only the original 89,634 training rows. Original validation rows are split into group-disjoint calibration and threshold-selection subsets. Original test rows are only used for evaluation and demonstration selection. No primary test examples enter challenger fitting, calibration or threshold selection. Existing test metrics were already available before this audit, so this is a reused benchmark rather than a newly collected prospective test.

Sigmoid calibration does not guarantee perfect calibration; Brier scores, log loss and reliability bins are saved. The primary model's calibration and threshold are preserved. The primary used the complete original validation set for model and threshold selection, so challenger validation-half scores are not an independent evaluation of the primary. Compare final holdout results instead.

Primary reference: [scikit-learn probability calibration](https://scikit-learn.org/stable/modules/calibration.html) explains separate calibration data; [threshold tuning guidance](https://scikit-learn.org/stable/modules/classification_threshold.html) warns against fitting and tuning a threshold on the same data.
